package com.ssenono.webview

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.ssenono.webview.R.*


class MainActivity : AppCompatActivity() {
    private val wview:WebView?=null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_main)
        //Give the app a title
        title="ROBERTS CALC"
        val wview = findViewById<WebView>(R.id.webview)
        wview.webViewClient= WebViewClient()
        //WEB VIEW IS THE OBJECT RESPONSIBLE FOR MOST OF THE ACTIONS INSIDE THE WEBSITE
        val webString = wview.settings
        val webSettings = wview.settings
        webSettings.javaScriptEnabled = true

        val url = "https://www.intellectsoft.net"
        wview.loadUrl(url)

    }

    override fun onBackPressed() {
        if(wview!!.canGoBack()){
            wview.goBack()
            //can go back
            //This method specifies the webview has a back history item
        }
        else

        super.onBackPressed()
    }

}